package service;


import controller.DTO.ConsultasDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import repository.ConsultasRepository;
import org.springframework.data.domain.Pageable;


import java.util.List;
import java.util.Optional;

@Service
public class ConsultasService {
    private final ConsultasRepository consultasRepository;

    public ConsultasService(ConsultasRepository consultasRepository){
        this.consultasRepository = consultasRepository;
    }

    public List<ConsultasDTO> findAll(Pageable pageable) {
        return consultasRepository.findAll(pageable).getContent().stream().map(ConsultasDTO::new).toList();
    }


    public Optional<ConsultasDTO> findById(Long id) {
        return consultasRepository.findById(id).map(ConsultasDTO::new);
    }


}

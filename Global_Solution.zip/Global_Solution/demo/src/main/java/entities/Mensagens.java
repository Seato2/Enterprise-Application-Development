package entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor

public class Mensagens {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long Id;

    private String Remetente;
    private String Conteudo;
    private LocalDateTime DataHoraEnvio;

    @ManyToOne
    @JoinColumn(name = "ID_Consulta")
    private Consultas consultas;


}

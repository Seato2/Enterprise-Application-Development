package entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "Diagnosticos")
public class Diagnosticos {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long Id;

    private String DescricaoDiagnostico;
    private String TratamentoRecomendado;

    @ManyToOne
    @JoinColumn(name = "ID_Consulta")
    private Consultas consultas;
}

package entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "HistoricoConsultas")
public class HistoricoConsultas {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long Id;

    private LocalDateTime DataHoraInicio;
    private LocalDateTime DataHoraFim;

    @ManyToOne
    @JoinColumn(name = "ID_Paciente")
    private Pacientes pacientes;

    @ManyToOne
    @JoinColumn(name = "ID_Paciente")
    private Consultas consultas;

}

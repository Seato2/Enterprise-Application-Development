package org.example;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.OffsetDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "cliente")
public class Cliente {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long cnpj;
    private Long cpf;
    private String email;
    private Long telefone;
    private OffsetDateTime data_cadastro;


    @ManyToOne
    @JoinColumn(name = "id_pedido")
    private Pedido pedido;




}

package org.example;


import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "produto_pedido")
public class Produto_Pedido {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private int quantidade;
    private double preco;


    @OneToMany(mappedBy = "produto_pedido")
    private List<Produto> produtos;

    @OneToMany(mappedBy = "produto_pedido")
    private List<Pedido> pedidos;


}
